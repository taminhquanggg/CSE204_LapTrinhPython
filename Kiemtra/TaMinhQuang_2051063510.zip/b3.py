s = input("Nhap S: ")
k = s.count('!')
if k != 0:
    print("S chua",k,"dau cham than")
else:
    print("S khong chua dau cham than")